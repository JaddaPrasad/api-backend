﻿using System;

namespace LoginApi.Exceptions
{
    //class
    public class UserExistException:ApplicationException
    {
        #region Constructors
        public UserExistException()
        {

        }

        public UserExistException(string message):base(message)
        {

        }
        #endregion

    }
}
