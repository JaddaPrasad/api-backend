﻿using System;

namespace LoginApi.Exceptions
{
    //class
    public class UserNotFoundException:ApplicationException
    {
        #region Constructors
        public UserNotFoundException()
        {

        }

        public UserNotFoundException(string message):base(message)
        {

        }
        #endregion
    }
}
