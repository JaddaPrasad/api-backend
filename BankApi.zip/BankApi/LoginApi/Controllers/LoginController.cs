﻿using Login.AOP;
using LoginApi.Models;
using LoginApi.Service;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace LoginApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    //[ServiceFilter(typeof(LoggingAttribute))]
    //[ServiceFilter(typeof(LoggingAttribute))]
    //[EnableCors("MyPolicy")]
    public class LoginController : ControllerBase
    {
        readonly ILoginService loginService;

        #region Constructors
        public LoginController(ILoginService _loginService)
        {
            loginService=_loginService;
        }

        #endregion

        #region Controller Action Methods

        [HttpPost]
        [Route("Register")]
        public async Task<ActionResult> RegisterAsync([FromBody]User user)
        {
            
            return StatusCode(201,await loginService.RegisterUserAsync(user));
        }

        [HttpPut]
        [Route("UpdateUser")]
        public async Task<ActionResult> UpdateUserAsync([FromBody] User user)
        {
            
            return StatusCode(200,await loginService.UpdateUserAsync(user));
        }

        [HttpGet]
        [Route("Login")]
        public async Task<ActionResult> LoginAsync(string userName,string password)
        {
            var user=await loginService.LoginUserAsync(userName,password);
            if (user !=null)
            {
                return Ok(user);
            }
            return NotFound("");
        }

        [HttpGet]
        [Route("GetAllUsers")]
        public async Task<ActionResult> GetAllUsersAsync()
        {
            return StatusCode(200,await loginService.GetAllUsersAsync());
        }

        [HttpGet]
        [Route("GetUserByName")]
        public async Task<ActionResult> GetAllUserByNameAsync(string name)
        {
            return StatusCode(200, await loginService.GetUserByNameAsync(name));
        }

        #endregion

    }
}
