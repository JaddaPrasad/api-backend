﻿using LoginApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LoginApi.Repo
{
    //interface
    public interface ILoginRepository
    {
        #region function Declarations
        Task<int> RegisterUserAsync(User user);

        Task<int> UpdateUserAsync(User user);

        void LoginUser(string userName, string password);

        Task<User> GetUserByNameAsync(string userName);

        Task<List<User>> GetAllUsersAsync();

        Task<User> GetUserDetailsByNameAndPasswordAsync(string userName,string password);

        Task<User> GetUserDetailsByEmailAndPasswordAsync(string userName, string password);

        #endregion
    }
}
