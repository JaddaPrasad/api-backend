﻿using LoginApi.Context;
using LoginApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginApi.Repo
{
    //class implements interface
    public class LoginRepository:ILoginRepository
    {
        readonly LoginDbContext loginDbContext;

        #region Constructors
        public LoginRepository(LoginDbContext _loginDbContext)
        {
            loginDbContext = _loginDbContext;
        }
        #endregion

        #region Repository Action Methods
        public async Task<List<User>> GetAllUsersAsync()
        {
            return await loginDbContext.Users.AsNoTracking().ToListAsync();
        }


        public async Task<User> GetUserByNameAsync(string userName)
        {
            return await loginDbContext.Users.Where(u => u.Username == userName).AsNoTracking().FirstOrDefaultAsync();
        }

        public async Task<User> GetUserDetailsByEmailAndPasswordAsync(string email, string password)
        {
            return await loginDbContext.Users.Where(u => u.Emailaddress == email && u.Password == password).AsNoTracking().FirstOrDefaultAsync();
        }

        public async Task<User> GetUserDetailsByNameAndPasswordAsync(string userName, string password)
        {
            return await loginDbContext.Users.Where(u => u.Username == userName && u.Password == password).AsNoTracking().FirstOrDefaultAsync();
        }

        public void LoginUser(string userName, string password)
        {
            
        }

        public async Task<int> RegisterUserAsync(User user)
        {
            loginDbContext.Users.Add(user);
            return await loginDbContext.SaveChangesAsync();
        }

        public async Task<int> UpdateUserAsync(User user)
        {
            loginDbContext.Users.Update(user);
            return await loginDbContext.SaveChangesAsync();
        }
        #endregion
    }
}
