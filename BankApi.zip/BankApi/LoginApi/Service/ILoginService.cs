﻿using LoginApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginApi.Service
{
    //interface
    public interface ILoginService
    {
        #region function declarations
        Task<int> RegisterUserAsync(User user);

        Task<int> UpdateUserAsync(User user);
        Task<User> LoginUserAsync(string userName,string passwod);

        Task<List<User>> GetAllUsersAsync();

        Task<User> GetUserByNameAsync(string userName);
        Task<User> GetUserDetailsByNameAndPasswordAsync(string userName, string password);

        Task<User> GetUserDetailsByEmailAndPasswordAsync(string userName, string password);
        #endregion
    }
}
