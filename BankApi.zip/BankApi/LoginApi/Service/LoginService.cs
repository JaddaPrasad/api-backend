﻿using LoginApi.Exceptions;
using LoginApi.Models;
using LoginApi.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginApi.Service
{
    //class
    public class LoginService:ILoginService
    {

        readonly ILoginRepository loginRepository;

        #region Constructors
        public LoginService(ILoginRepository _loginRepository)
        {
            loginRepository = _loginRepository;
        }
        #endregion

        #region Service function declarations
        public async Task<List<User>> GetAllUsersAsync()
        {
            return await loginRepository.GetAllUsersAsync();
        }

        public async Task<User> GetUserByNameAsync(string userName)
        {
            return await loginRepository.GetUserByNameAsync(userName);
        }

        public async Task<User> GetUserDetailsByEmailAndPasswordAsync(string userEmail, string password)
        {
            return await loginRepository.GetUserDetailsByEmailAndPasswordAsync(userEmail, password);
        }

        public async Task<User> GetUserDetailsByNameAndPasswordAsync(string userName, string password)
        {
            return await loginRepository.GetUserDetailsByNameAndPasswordAsync(userName, password);
        }

        public async Task<User> LoginUserAsync(string userName,string password)
        {
            var userExist = await loginRepository.GetUserDetailsByNameAndPasswordAsync(userName,password);
            if (userExist == null)
            {
                throw new UserNotFoundException($"User with name:: {userName} Not Found!!");
            }
            else
            {
                return userExist;
            }
        }

        public async Task<int> RegisterUserAsync(User user)
        {
            var userExist = await loginRepository.GetUserByNameAsync(user.Username);
            if (userExist == null)
            {
                return await loginRepository.RegisterUserAsync(user);
            }
            else
            {
                throw new UserExistException($"User with name:: {user.Username} already Exist!!");
            }
        }

        public async Task<int> UpdateUserAsync(User user)
        {
            return await loginRepository.UpdateUserAsync(user);
        }
        #endregion
    }
}
