﻿using LoginApi.Models;
using Microsoft.EntityFrameworkCore;

namespace LoginApi.Context
{
    //class
    public class LoginDbContext:DbContext
    {
        //constructor
        public LoginDbContext(DbContextOptions<LoginDbContext> options):base(options)
        {
            Database.EnsureCreated();
        }

        /*protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().Property(u => u.UserName).IsRequired();
        }*/

        //DBset table declaration
        public DbSet<User> Users { get; set; }
    }
}
