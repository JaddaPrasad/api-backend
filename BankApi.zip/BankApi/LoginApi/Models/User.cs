﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace LoginApi.Models
{
    //class
    public class User
    {

        #region Properties
        [Key]
        //[JsonIgnore]
        public int UId { get; set; }

        public string Name { get; set; }

        public string Customerid { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public string Guardiantype { get; set; }

        public string Guardianname { get; set; }

        public string Address { get; set; }

        public string Citizenship { get; set; }

        public string State { get; set; }

        public string Country { get; set; }

        public string Emailaddress { get; set; }

        public string Gender { get; set; }

        public string Maritalstatus { get; set; }

        public string Contactno { get; set; }

        public string Dob { get; set; }

        public string Regdate { get; set; }

        public string Accounttype { get; set; }

        public string Branchname { get; set; }

        public string Citizenstatus { get; set; }

        public string Initialdepamount { get; set; }

        public string Idprooftype { get; set; }

        public string Iddocnumber { get; set; }

        public string Refaccholdername { get; set; }

        public string Refaccholderaccnumber { get; set; }

        public string Refaccholderaddress { get; set; }

        #endregion

    }
}
