﻿using LoginApi.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Login.AOP
{
    public class ExceptionHandlerAttribute:ExceptionFilterAttribute
    {

        public override void OnException(ExceptionContext context)
        {
            if (context.Exception.GetType() == typeof(UserNotFoundException))
            {
                context.Result = new NotFoundObjectResult(context.Exception.Message);

            }else if (context.Exception.GetType() == typeof(UserExistException))
            {
                context.Result = new ConflictObjectResult(context.Exception.Message);
            }
            else
            {
                context.Result = new StatusCodeResult(500);
            }
        }

    }
}
