﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.IO;

namespace LoginApi.AOP
{
    public class LoggingAttribute:ActionFilterAttribute
    {
        readonly string logFile;
        public LoggingAttribute(IWebHostEnvironment environment)
        {
            logFile = environment.ContentRootPath + "userlog.txt";
            logFile = environment.ContentRootPath + @"/userlog/userlog.txt";
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            using (StreamWriter streamWriter = File.AppendText(logFile))
            {
                var controllerBase = (ControllerBase)context.Controller;
                var controllerContext = controllerBase.ControllerContext;
                var controllerName = controllerContext.ActionDescriptor.ControllerName;
                var actionName = controllerContext.ActionDescriptor.ActionName;
                streamWriter.WriteLine($"\nDate::{DateTime.Now} ControllerName::{controllerName} ActionName::{actionName}");
                streamWriter.Close();
            }
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            base.OnActionExecuted(context);
        }

    }
}
