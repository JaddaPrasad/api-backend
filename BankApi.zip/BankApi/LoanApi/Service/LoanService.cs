﻿using LoanApi.Models;
using LoanApi.Repo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LoanApi.Service
{
    public class LoanService : ILoanService
    {

        readonly ILoanRepo loanRepo;

        public LoanService(ILoanRepo _loanRepo)
        {
            loanRepo = _loanRepo;
        }

        public async Task<int> AddLoanAsync(Loan loan)
        {
            return await loanRepo.AddLoanAsync(loan);
        }

        public async Task<int> DeleteLoanAsync(int loanId)
        {
            var loanExist = await loanRepo.GetLoanByIdAsync(loanId);
            if (loanExist == null)
            {
                return 0;
                //throw new AirlineNotFoundException($"Airline with id::{airlineId} does not Exist!!");
            }
            else
            {
                return await loanRepo.DeleteLoanAsync(loanExist.Loanid);
            }
        }

        public async Task<List<Loan>> GetAllLoansAsync()
        {
            return await loanRepo.GetAllLoansAsync();
        }

        public async Task<Loan> GetLoanByIdAsync(int loanId)
        {
            var loanExist = loanRepo.GetLoanByIdAsync(loanId);
            if (loanExist != null)
            {
                return await loanExist;
            }
            else
            {
                return null;
                //throw new AirlineNotFoundException($"Airline with id::{airlineId} does not Exist!!");
            }
        }

        public async Task<int> UpdateLoanAsync(Loan loan)
        {
            var loanExist = await loanRepo.GetLoanByIdAsync(loan.Loanid);
            if (loanExist != null)
            {
                return await loanRepo.UpdateLoanAsync(loan);
            }
            else
            {
                return 0;
                //throw new AirlineExistException($"{airline.AirlineName} Exist!!");
            }
        }
    }
}
