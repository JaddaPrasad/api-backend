﻿using LoanApi.Models;
using LoanApi.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Service
{
    public class PersonalLoanService : IPersonalLoanService
    {

        readonly IPersonalLoanRepo personalRepo;

        public PersonalLoanService(IPersonalLoanRepo _personalRepo)
        {
            personalRepo = _personalRepo;
        }

        public async Task<int> AddLoanAsync(PersonalLoan personalloan)
        {
            return await personalRepo.AddLoanAsync(personalloan);
        }

        public async Task<int> DeleteLoanAsync(int loanId)
        {
            var loanExist = await personalRepo.GetLoanByIdAsync(loanId);
            if (loanExist == null)
            {
                return 0;
            }
            else
            {
                return await personalRepo.DeleteLoanAsync(loanExist.Loanid);
            }
        }

        public async Task<List<PersonalLoan>> GetAllLoansAsync()
        {
            return await personalRepo.GetAllLoansAsync();
        }

        public async Task<PersonalLoan> GetLoanByIdAsync(int loanId)
        {
            var loanExist = personalRepo.GetLoanByIdAsync(loanId);
            if (loanExist != null)
            {
                return await loanExist;
            }
            else
            {
                return null;
            }
        }

        public async Task<int> UpdateLoanAsync(PersonalLoan personalloan)
        {
            var loanExist = await personalRepo.GetLoanByIdAsync(personalloan.Loanid);
            if (loanExist != null)
            {
                return await personalRepo.UpdateLoanAsync(personalloan);
            }
            else
            {
                return 0;
            }
        }
    }
}
