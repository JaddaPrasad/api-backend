﻿using LoanApi.Models;
using LoanApi.Repo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LoanApi.Service
{
    public class EduLoanService : IEduLoanService
    {
        readonly IEduLoanRepo eduLoanRepo;

        public EduLoanService(IEduLoanRepo _eduLoanRepo)
        {
            eduLoanRepo = _eduLoanRepo;
        }

        public async Task<int> AddLoanAsync(EduLoan eduloan)
        {
            return await eduLoanRepo.AddLoanAsync(eduloan);
        }

        public async Task<int> DeleteLoanAsync(int loanId)
        {
            var loanExist = await eduLoanRepo.GetLoanByIdAsync(loanId);
            if (loanExist == null)
            {
                return 0;
            }
            else
            {
                return await eduLoanRepo.DeleteLoanAsync(loanExist.Loanid);
            }
        }

        public async Task<List<EduLoan>> GetAllLoansAsync()
        {
            return await eduLoanRepo.GetAllLoansAsync();
        }

        public async Task<EduLoan> GetLoanByIdAsync(int loanId)
        {
            var loanExist = eduLoanRepo.GetLoanByIdAsync(loanId);
            if (loanExist != null)
            {
                return await loanExist;
            }
            else
            {
                return null;
            }
        }

        public async Task<int> UpdateLoanAsync(EduLoan eduloan)
        {
            var loanExist = await eduLoanRepo.GetLoanByIdAsync(eduloan.Loanid);
            if (loanExist != null)
            {
                return await eduLoanRepo.UpdateLoanAsync(eduloan);
            }
            else
            {
                return 0;
            }
        }
    }
}
