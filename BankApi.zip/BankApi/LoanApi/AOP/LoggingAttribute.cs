﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.AOP
{
    public class LoggingAttribute
    {
    }
}
