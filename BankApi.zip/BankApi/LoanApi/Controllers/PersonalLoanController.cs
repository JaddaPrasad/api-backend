﻿using LoanApi.Models;
using LoanApi.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonalLoanController : ControllerBase
    {
        readonly IPersonalLoanService personalLoanService;

        #region Constructors
        public PersonalLoanController(IPersonalLoanService _personalLoanService)
        {
            personalLoanService = _personalLoanService;
        }
        #endregion

        #region Controller Action Methods

        [HttpGet]
        [Route("GetAllPersonalLoans")]
        public async Task<ActionResult> GetAllLoans()
        {
            return Ok(await personalLoanService.GetAllLoansAsync());
        }

        [HttpGet]
        [Route("GetPersonalLoanBYId")]
        public async Task<ActionResult> GetLoanBYId(int loanId)
        {
            return Ok(await personalLoanService.GetLoanByIdAsync(loanId));

        }


        [HttpPost]
        [Route("AddPersonalLoan")]
        public async Task<ActionResult> AddLoan([FromBody] PersonalLoan loan)
        {
            return StatusCode(201, await personalLoanService.AddLoanAsync(loan));

        }

        [HttpPut]
        [Route("UpdatePersonalLoan")]
        public async Task<ActionResult> UpdateLoan([FromBody] PersonalLoan loan)
        {
            return StatusCode(200, await personalLoanService.UpdateLoanAsync(loan));
        }

        [HttpDelete]
        [Route("DeletePersonalLoan")]
        public async Task<ActionResult> DeleteLoan(int loanId)
        {
            return Ok(await personalLoanService.DeleteLoanAsync(loanId));
        }

        #endregion
    }
}
