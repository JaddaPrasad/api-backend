﻿using LoanApi.Models;
using LoanApi.Service;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace LoanApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EduLoanController : ControllerBase
    {
        readonly IEduLoanService eduLoanService;

        #region Constructors
        public EduLoanController(IEduLoanService _eduLoanService)
        {
            eduLoanService = _eduLoanService;
        }
        #endregion

        #region Controller Action Methods

        [HttpGet]
        [Route("GetAllEduLoans")]
        public async Task<ActionResult> GetAllEduLoans()
        {
            return Ok(await eduLoanService.GetAllLoansAsync());
        }

        [HttpGet]
        [Route("GetEduLoanBYId")]
        public async Task<ActionResult> GetEduLoanBYId(int loanId)
        {
            return Ok(await eduLoanService.GetLoanByIdAsync(loanId));

        }


        [HttpPost]
        [Route("AddEduLoan")]
        public async Task<ActionResult> AddEduLoan([FromBody] EduLoan loan)
        {
            return StatusCode(201, await eduLoanService.AddLoanAsync(loan));

        }

        [HttpPut]
        [Route("UpdateEduLoan")]
        public async Task<ActionResult> UpdateEduLoan([FromBody] EduLoan loan)
        {
            return StatusCode(200, await eduLoanService.UpdateLoanAsync(loan));
        }

        [HttpDelete]
        [Route("DeleteEduLoan")]
        public async Task<ActionResult> DeleteEduLoan(int loanId)
        {
            return Ok(await eduLoanService.DeleteLoanAsync(loanId));
        }

        #endregion
    }
}
