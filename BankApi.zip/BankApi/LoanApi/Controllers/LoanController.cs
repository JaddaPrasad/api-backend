﻿using LoanApi.Models;
using LoanApi.Service;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace LoanApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanController : ControllerBase
    {

        readonly ILoanService loanService;

        #region Constructors
        public LoanController(ILoanService _loanService)
        {
            loanService = _loanService;
        }
        #endregion

        #region Controller Action Methods

        [HttpGet]
        [Route("GetAllLoans")]
        public async Task<ActionResult> GetAllLoans()
        {
            return Ok(await loanService.GetAllLoansAsync());
        }

        [HttpGet]
        [Route("GetLoanBYId")]
        public async Task<ActionResult> GetLoanBYId(int loanId)
        {
            return Ok(await loanService.GetLoanByIdAsync(loanId));

        }


        [HttpPost]
        [Route("AddLoan")]
        public async Task<ActionResult> AddLoan([FromBody] Loan loan)
        {
            return StatusCode(201, await loanService.AddLoanAsync(loan));

        }

        [HttpPut]
        [Route("UpdateLoan")]
        public async Task<ActionResult> UpdateLoan([FromBody] Loan loan)
        {
            return StatusCode(200, await loanService.UpdateLoanAsync(loan));
        }

        [HttpDelete]
        [Route("DeleteLoan")]
        public async Task<ActionResult> DeleteLoan(int loanId)
        {
            return Ok(await loanService.DeleteLoanAsync(loanId));
        }

        #endregion

    }
}
