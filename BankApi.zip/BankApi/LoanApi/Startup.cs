using LoanApi.AOP;
using LoanApi.Context;
using LoanApi.Repo;
using LoanApi.Service;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddCors();
            services.AddMvc();

            var connectionString = Environment.GetEnvironmentVariable("sql_login_docker_image_connection");
            if (connectionString == null)
            {
                connectionString = Configuration.GetConnectionString("sqlConnectionLoanApi");
            }

            services.AddDbContext<LoanDbContext>(a => a.UseSqlServer(connectionString));
            services.AddScoped<ILoanRepo, LoanRepo>();
            services.AddScoped<IEduLoanRepo, EduLoanRepo>();
            services.AddScoped<IPersonalLoanRepo, PersonalLoanRepo>();
            services.AddScoped<ILoanService, LoanService>();
            services.AddScoped<IEduLoanService, EduLoanService>();
            services.AddScoped<IPersonalLoanService, PersonalLoanService>();
            services.AddScoped<LoggingAttribute>();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Loan API", Version = "v1" });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors(
                options => options.WithOrigins("http://localhost:3000").AllowAnyHeader().AllowAnyMethod()
            );

            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("v1/swagger.json", "Loan API V1");
            });

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
