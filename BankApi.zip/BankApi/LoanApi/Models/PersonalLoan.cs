﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Models
{
    public class PersonalLoan
    {
        [Key]
        public int PersonalLoanId { get; set; }

        public int Loanid { get; set; }

        public string Annualincome { get; set; }

        public string Companyname { get; set; }

        public string Designation { get; set; }

        public string Totalexp { get; set; }

        public string Currentexp { get; set; }

    }
}
