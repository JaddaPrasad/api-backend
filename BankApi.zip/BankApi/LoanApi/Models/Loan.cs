﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Models
{
    public class Loan
    {
        [Key]
        public int Loanid { get; set; }

        public int Userid { get; set; }

        public string Loantype { get; set; }

        public string Loanamount { get; set; }

        public string Applydate { get; set; }

        public string Issuedate { get; set; }

        public string Rateofintrest { get; set; }

        public string Durationofloan { get; set; }

    }
}
