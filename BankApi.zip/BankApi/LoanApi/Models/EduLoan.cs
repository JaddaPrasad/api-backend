﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Models
{
    public class EduLoan
    {
        [Key]
        public int EduLoanId { get; set; }

        public int Loanid { get; set; }

        public string Coursefee { get; set; }

        public string Course { get; set; }

        public string Fathername { get; set; }

        public string Fatheroccupation { get; set; }

        public string fathertotalexperince { get; set; }

        public string Fathercurrentexperience { get; set; }

        public string Rationcardno { get; set; }

        public string Annualincome { get; set; }
    }
}
