﻿using LoanApi.Models;
using Microsoft.EntityFrameworkCore;

namespace LoanApi.Context
{
    public class LoanDbContext:DbContext
    {
        public LoanDbContext(DbContextOptions<LoanDbContext> options):base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<Loan> Loans { get; set; }

        public DbSet<EduLoan> EduLoans { get; set; }

        public DbSet<PersonalLoan> PersonalLoans { get; set; }

    }
}
