﻿using LoanApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Repo
{
    public interface IEduLoanRepo
    {
        #region function declarations
        Task<int> AddLoanAsync(EduLoan eduloan);

        Task<int> UpdateLoanAsync(EduLoan eduloan);


        Task<List<EduLoan>> GetAllLoansAsync();

        Task<EduLoan> GetLoanByIdAsync(int loanId);
        Task<int> DeleteLoanAsync(int loanId);
        #endregion
    }
}
