﻿using LoanApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Repo
{
    public interface ILoanRepo
    {

        #region function declarations
        Task<int> AddLoanAsync(Loan loan);

        Task<int> UpdateLoanAsync(Loan loan);


        Task<List<Loan>> GetAllLoansAsync();

        Task<Loan> GetLoanByIdAsync(int loanId);
        Task<int> DeleteLoanAsync(int loanId);
        #endregion

    }
}
