﻿using LoanApi.Context;
using LoanApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Repo
{
    public class EduLoanRepo : IEduLoanRepo
    {
        readonly LoanDbContext loanDbContext;

        #region Constructors
        public EduLoanRepo(LoanDbContext _loanDbContext)
        {
            loanDbContext = _loanDbContext;
        }
        #endregion

        public async Task<int> AddLoanAsync(EduLoan eduloan)
        {
            loanDbContext.EduLoans.Add(eduloan);
            return await loanDbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteLoanAsync(int loanId)
        {
            var loanExist = await loanDbContext.EduLoans.Where(el => el.EduLoanId == loanId).FirstOrDefaultAsync();
            loanDbContext.EduLoans.Remove(loanExist);
            return await loanDbContext.SaveChangesAsync();
        }

        public async Task<List<EduLoan>> GetAllLoansAsync()
        {
            return await loanDbContext.EduLoans.AsNoTracking().ToListAsync();
        }

        public async Task<EduLoan> GetLoanByIdAsync(int loanId)
        {
            EduLoan loan = await loanDbContext.EduLoans.Where(el => el.EduLoanId == loanId).AsNoTracking().FirstOrDefaultAsync();
            return loan;
        }

        public async Task<int> UpdateLoanAsync(EduLoan eduloan)
        {
            loanDbContext.EduLoans.Update(eduloan);
            return await loanDbContext.SaveChangesAsync();
        }
    }
}
