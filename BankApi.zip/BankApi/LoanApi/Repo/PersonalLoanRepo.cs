﻿using LoanApi.Context;
using LoanApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Repo
{
    public class PersonalLoanRepo : IPersonalLoanRepo
    {
        readonly LoanDbContext loanDbContext;

        #region Constructors
        public PersonalLoanRepo(LoanDbContext _loanDbContext)
        {
            loanDbContext = _loanDbContext;
        }
        #endregion

        public async Task<int> AddLoanAsync(PersonalLoan personalloan)
        {
            loanDbContext.PersonalLoans.Add(personalloan);
            return await loanDbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteLoanAsync(int loanId)
        {
            var loanExist = await loanDbContext.PersonalLoans.Where(pl => pl.PersonalLoanId == loanId).FirstOrDefaultAsync();
            loanDbContext.PersonalLoans.Remove(loanExist);
            return await loanDbContext.SaveChangesAsync();
        }

        public async Task<List<PersonalLoan>> GetAllLoansAsync()
        {
            return await loanDbContext.PersonalLoans.AsNoTracking().ToListAsync();
        }

        public async Task<PersonalLoan> GetLoanByIdAsync(int loanId)
        {
            PersonalLoan loan = await loanDbContext.PersonalLoans.Where(pl => pl.PersonalLoanId == loanId).AsNoTracking().FirstOrDefaultAsync();
            return loan;
        }

        public async Task<int> UpdateLoanAsync(PersonalLoan personalloan)
        {
            loanDbContext.PersonalLoans.Update(personalloan);
            return await loanDbContext.SaveChangesAsync();
        }
    }
}
