﻿using LoanApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Repo
{
    public interface IPersonalLoanRepo
    {
        #region function declarations
        Task<int> AddLoanAsync(PersonalLoan personalloan);

        Task<int> UpdateLoanAsync(PersonalLoan personalloan);


        Task<List<PersonalLoan>> GetAllLoansAsync();

        Task<PersonalLoan> GetLoanByIdAsync(int loanId);
        Task<int> DeleteLoanAsync(int loanId);
        #endregion
    }
}
