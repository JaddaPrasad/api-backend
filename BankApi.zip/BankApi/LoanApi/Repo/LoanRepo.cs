﻿using LoanApi.Context;
using LoanApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoanApi.Repo
{
    public class LoanRepo : ILoanRepo
    {
        readonly LoanDbContext loanDbContext;

        #region Constructors
        public LoanRepo(LoanDbContext _loanDbContext)
        {
            loanDbContext = _loanDbContext;
        }
        #endregion

        #region Repository Action Methods
        public async Task<int> AddLoanAsync(Loan loan)
        {
            loanDbContext.Loans.Add(loan);
            return await loanDbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteLoanAsync(int loanId)
        {
            var loanExist = await loanDbContext.Loans.Where(l => l.Loanid == loanId).FirstOrDefaultAsync();
            loanDbContext.Loans.Remove(loanExist);
            return await loanDbContext.SaveChangesAsync();
        }

        public async Task<List<Loan>> GetAllLoansAsync()
        {
            return await loanDbContext.Loans.AsNoTracking().ToListAsync();
        }

        public async Task<Loan> GetLoanByIdAsync(int loanId)
        {
            Loan loan = await loanDbContext.Loans.Where(l => l.Loanid == loanId).AsNoTracking().FirstOrDefaultAsync();
            return loan;
        }

        public async Task<int> UpdateLoanAsync(Loan loan)
        {
            loanDbContext.Loans.Update(loan);
            return await loanDbContext.SaveChangesAsync();
        }
        #endregion
    }
}
